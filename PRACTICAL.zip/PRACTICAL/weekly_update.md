# Weekly progress update
Project:
Reporting period:
Prepared by:
Task IDs affected:
Completed work and supporting evidence:
Current completion percentage for each task:
Blockers and their impact:
Risks or dependency changes:
Decisions required and decision owner:
Next actions, owners and proposed dates:
Date of this update:
