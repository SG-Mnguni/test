# Project brief
Project name: University Project Monitoring Agent (UPM) 
Sponsor: Head of Department, Computer Science and IT 
Project manager: Project lead 
Objective and measurable success criteria: Deliver a web application that tracks software project tasks; zero open critical defects at acceptance; sponsor demonstration completed by 2026-10-16. 
Approved scope and exclusions: Task tracking, weekly status reporting, document retrieval. Excluded: budget tracking, automatic emailing, multi-user access. 
Start date: 2026-08-03 
Target finish date: 2026-10-30 
Milestones and acceptance criteria: M1 Requirements confirmed (2026-09-18); M2 Core build complete (2026-10-02); M3 System testing passed with no open critical defects (2026-10-09); M4 Sponsor demonstration (2026-10-16); M5 Handover (2026-10-30). 
Approved budget and actual spending (if applicable): Not tracked in this project.
Dependencies: M3 depends on M2. M4 depends on M3 and on fixing all critical defects.
Risks, likelihood, impact, mitigation and owner: R1 Critical defects delay demonstration (likelihood high, impact high, mitigation: dedicated fix sprint, owner: Developer). R2 Sponsor feedback delayed (likelihood medium, impact medium, mitigation: feedback deadline, owner: Project lead). 
Reporting frequency: Weekly, every Friday. 
Approved status rules: Red = critical task overdue or blocked; Amber = other task overdue, blocked or due within 7 days; Unknown = update older than 7 days; otherwise Green. 
Baseline version and approval date: Baseline v1.0, approved 2026-08-01. Baseline deadlines may only change with project manager approval.