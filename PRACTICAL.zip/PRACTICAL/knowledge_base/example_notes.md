# Demonstration notes — fictional
The sponsor must confirm requirements before the prototype is finalised. The demo requirements task is blocked pending sponsor feedback. A recovery plan should identify a feedback deadline and an escalation owner. These notes are demonstration evidence, not a real project update.
